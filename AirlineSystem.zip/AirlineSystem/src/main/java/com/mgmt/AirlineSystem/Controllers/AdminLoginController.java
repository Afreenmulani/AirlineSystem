//package com.mgmt.AirlineSystem.Controllers;
//
//import org.springframework.stereotype.Controller;
//
//@Controller
//public class AdminLoginController {
//	@Autowired
//	private AdminService adminservice;
//
//@GetMapping("/adminlogin")
//	public String getadminLogin(Model model) {
//		
//		model.addAttribute("adminHome", new AdminHome());
//		
//		return "Adminhome";
//		
//  }
//@PostMapping("/adminloginstatus")
//public String getadminlogStatus(@Validated @ModelAttribute("adminHome") AdminHome adminHome,BindingResult bindResult,Model model) {
//	if(bindResult.hasErrors()) {
//		return "Adminhome";
//	}
//	List<com.mgmt.AirlineSystem.entity.Admin> dbAdminList=adminservice.adminList();
//	boolean found=false;
//	
//	for(com.mgmt.AirlineSystem.entity.Admin dba:dbAdminList) {
//		if(dba.getUsername().equals(adminHome.getUsername()) && dba.getPassword().equals(adminHome.getPassword())){
//			
//			found=true;
//			break;
//		}
//	}
//	
//if(found==true) {
//
//	 return "admindashboard"; 
// 
//
//
//}else {
//	model.addAttribute("error","incorrect username or password");
//	return "Adminhome";
//	
//}
//	
//}
//
//}
