package com.mgmt.AirlineSystem.entity;


import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

    private String flightNumber;
    private String source;
    private String destination;
    private int numberOfPassengers;
    private LocalDateTime departureTime;
    private LocalDateTime returnTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}
	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}
	public LocalDateTime getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}
	public LocalDateTime getReturnTime() {
		return returnTime;
	}
	public void setReturnTime(LocalDateTime returnTime) {
		this.returnTime = returnTime;
	}
	@Override
	public String toString() {
		return "Flight [id=" + id + ", flightNumber=" + flightNumber + ", source=" + source + ", destination="
				+ destination + ", numberOfPassengers=" + numberOfPassengers + ", departureTime=" + departureTime
				+ ", returnTime=" + returnTime + "]";
	}
	public Flight(int id, String flightNumber, String source, String destination, int numberOfPassengers,
			LocalDateTime departureTime, LocalDateTime returnTime) {
		super();
		this.id = id;
		this.flightNumber = flightNumber;
		this.source = source;
		this.destination = destination;
		this.numberOfPassengers = numberOfPassengers;
		this.departureTime = departureTime;
		this.returnTime = returnTime;
	}
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
