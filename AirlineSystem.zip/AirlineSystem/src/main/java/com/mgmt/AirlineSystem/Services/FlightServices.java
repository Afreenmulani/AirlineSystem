package com.mgmt.AirlineSystem.Services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mgmt.AirlineSystem.entity.Flight;

@Service
public interface FlightServices {
	
	public Flight getFlightById(int id);
	
	public List<Flight> getAllFlights();
	
	 public Flight saveFlight(Flight flight);
	 
	 public void deleteFlight(int id);
}
