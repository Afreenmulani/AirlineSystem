//package com.mgmt.AirlineSystem.Controllers;
//
//import org.springframework.stereotype.Controller;
//
//@Controller
//public class BookingController {
//	@Autowired
//	private BookingService bookingservice;
//	
//	
//	 @GetMapping("/managebooking")
//	    public String manageFlights(Model model) {
//	        model.addAttribute("booking", new Booking());
//			return "addbooking";
//	    }
//	  
//
//	    @PostMapping("/booking/add")
//	    public String addBooking(Booking booking) {
//	    	bookingservice.saveBooking(booking);
//	    	return "/payment";//check
//	    }
//
//	    @GetMapping("/listbooking")
//	    
//	    public String listbooking(Model model) {
//	        List<Booking> booking = bookingservice.getAllBooking();
//	        model.addAttribute("bookings", booking);
//	        return "bookinglist";
//	    }
//	
//	    @PostMapping("/flight/book")
//	    public String addPass(Model model) {
//	    	model.addAttribute("booking",new Booking());
//			return "addbooking";
//	    }
//
//}
