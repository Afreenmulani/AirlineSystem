package com.mgmt.AirlineSystem.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mgmt.AirlineSystem.Services.FlightServices;
import com.mgmt.AirlineSystem.entity.Flight;

@Controller
public class FlightController {

	@Autowired
	public FlightServices flightServices;
	
	@GetMapping("/flights")
    public String getAllFlights(Model model) {
        model.addAttribute("flights", flightServices.getAllFlights());
        return "flights";
    }

    @GetMapping("/flights/{id}")
    public String getFlightById(@PathVariable int id, Model model) {
        model.addAttribute("flight", flightServices.getFlightById(id));
        return "flight-details";
    }
	
	 @GetMapping("/enterFlightInfo")
	    public String showForm(Model model) {
	        model.addAttribute("flight", new Flight());
	        return "enterFlightInfo";
	    }

	    @PostMapping("/saveFlight")
	    public String saveFlight(@ModelAttribute Flight flight, Model model) {
	        flightServices.saveFlight(flight);
	        model.addAttribute("message", "Flight information saved successfully!");
	        return "success";
	    }
	    
	    @GetMapping("/flights/edit")
	    public String getEditForm(@RequestParam("id") int id, Model model) {
	    	Flight flight=flightServices.getFlightById(id);
	    	model.addAttribute("flight",flight);
	    	return "updateForm";
	    	
	    }
}
