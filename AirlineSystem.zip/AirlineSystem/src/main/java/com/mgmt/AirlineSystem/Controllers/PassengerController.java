package com.mgmt.AirlineSystem.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.mgmt.AirlineSystem.Services.PassengerServices;
import com.mgmt.AirlineSystem.entity.Passenger;

@Controller
public class PassengerController {
	
	@Autowired
	public PassengerServices passengerServices;
	

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("passenger", new Passenger());
        return "register";
    }

    @PostMapping("/register")
    public String registerPassenger(@ModelAttribute Passenger passenger) {
        passengerServices.savePassenger(passenger);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login() {
    
        return "login";
    }
    
    @PostMapping("/login")
    public String loginSubmit(Model model) {
        // Add your authentication logic here. For simplicity, assume login is always successful.
        // After successful login, redirect to enter flight info page.
        return "redirect:/enterFlightInfo";
    }
}
