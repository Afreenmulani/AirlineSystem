//package com.mgmt.AirlineSystem.Controllers;
//
//import org.springframework.stereotype.Controller;
//
//import jakarta.transaction.Transactional;
//
//@Controller
//@Transactional
//public class AdminRegController {
//	@Autowired
//	private AdminService adminservice;
//@GetMapping("/adminregister")
//public String regiAdmin(Model model) {
//	
//	model.addAttribute("admin", new Admin());
//	
//	return "AdminRegestration";
//	
//}
//@PostMapping("/adminstatus")
//public String getadminStatus(@Validated @ModelAttribute("admin") Admin admin,BindingResult bindResult) {
//	if(bindResult.hasErrors()) {
//		return "AdminRegestration";
//	}
//	adminservice.saveAdmin(admin);
//	return "redirect:/adminlogin";
//}
//
//}
