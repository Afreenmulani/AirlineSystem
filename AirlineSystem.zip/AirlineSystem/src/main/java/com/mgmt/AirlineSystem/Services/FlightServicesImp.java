package com.mgmt.AirlineSystem.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mgmt.AirlineSystem.Repository.FlightRepository;
import com.mgmt.AirlineSystem.entity.Flight;
@Service
public class FlightServicesImp implements FlightServices{

	 @Autowired
	public FlightRepository flightRepository;
	@Override
	public Flight getFlightById(int id) {
		return flightRepository.findById(id).orElse(null);
	}

	@Override
	public List<Flight> getAllFlights() {
		return flightRepository.findAll();
	}

	@Override
	public Flight saveFlight(Flight flight) {
		return flightRepository.save(flight);
	}

	@Override
	public void deleteFlight(int id) {
		flightRepository.deleteById(id);
	}

}
